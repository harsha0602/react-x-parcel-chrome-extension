import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';

class Button extends React.Component {
  render() {
    return (
      <button>
        Hello
      </button>
    )
  }
}

Button.propTypes = {
};

export default Button;